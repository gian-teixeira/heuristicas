#ifndef __TSP_H__
#define __TSP_H__

#include <provider.hpp>
#include <iostream>
#include <vector>

class TSPSolution : public std::vector<unsigned>
{
public:
    TSPSolution() {};
    TSPSolution(std::size_t size);
    TSPSolution swap(std::size_t i, std::size_t j);
};

class TSP : public Provider<TSPSolution, double>
{
private:
    std::size_t ncities;
    std::vector<std::vector<double>> distances;

public:
    TSP(std::size_t ncities, std::vector<std::vector<double>> distances);
    bool best(double a, double b) const override;
    std::vector<TSPSolution> neighborhood(TSPSolution solution) const override;
    double fitness(TSPSolution solution) const override;
    double null_fitness() const override;
    std::size_t size() const;
    static TSP read();
};

// std::ostream& operator << (
//     std::ostream &os, 
//     TSPSolution &solution)
// {
//     for(int i : solution) {
//         os << i << " ";
//     }
//     return os << "\n";
// }

#endif