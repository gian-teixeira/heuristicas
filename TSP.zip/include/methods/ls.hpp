#ifndef __LS_H__
#define __LS_H__

#include <random.hpp>
#include <provider.hpp>

template<typename SolutionType, typename FitnessType>
class LSManager
{
private:
    Provider<SolutionType,FitnessType> *provider;

public:
    LSManager(Provider<SolutionType,FitnessType> *provider) :
        provider(provider)
    {}

    SolutionType search(
        SolutionType initial,
        unsigned max)
    {
        Random rng;
        SolutionType solution = initial;
        SolutionType best_solution = initial;
        FitnessType solution_fitness = this->provider->fitness(solution);
        FitnessType best_fitness = solution_fitness;
        
        while(max--) {
            std::vector<SolutionType> neighbors = this->provider->neighborhood(solution);
            FitnessType neighbor_fitness = this->provider->null_fitness();
            SolutionType neighbor;

            for(SolutionType candidate : neighbors) {
                FitnessType candidate_fitness = this->provider->fitness(candidate);
                if(this->provider->best(candidate_fitness, neighbor_fitness)) {
                    neighbor_fitness = candidate_fitness;
                    neighbor = candidate;
                }
            }

            if(this->provider->best(neighbor_fitness, solution_fitness)) {
                solution_fitness = neighbor_fitness;
                solution = neighbor;
                if(this->provider->best(solution_fitness, best_fitness)) {
                    best_fitness = solution_fitness;
                    best_solution = solution;
                }
            }
        }

        return best_solution;
    }
};

#endif