#ifndef __PROVIDER_H__
#define __PROVIDER_H__

#include <vector>

template<typename SolutionType, typename FitnessType>
class Provider
{
public:
    using solution_type = SolutionType;
    using fitness_type = FitnessType;
    
    virtual std::vector<SolutionType> neighborhood(SolutionType solution) const = 0;
    virtual bool best(FitnessType a, FitnessType b) const = 0;
    virtual FitnessType fitness(SolutionType solution) const = 0;
    virtual FitnessType null_fitness() const = 0;
};

#endif