#include <random.hpp>
#include <random>
#include <cstdint>

Random::Random() : 
    device(),
    generator(device())
{}

double Random::rand()
{
    std::uniform_real_distribution<double> dist {0,1};
    return dist(this->generator);
}

uint64_t Random::randint(uint64_t low,
                    uint64_t high)
{
    std::uniform_int_distribution<uint64_t> dist {low,high};
    return dist(this->generator);
}

std::mt19937_64 Random::get_generator()
{
    return this->generator;
}