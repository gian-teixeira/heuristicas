#include <tsp.hpp>
#include <random.hpp>
#include <algorithm>
#include <vector>
#include <utility>
#include <iostream>
#include <cmath>
#include <numeric>
#include <limits>

TSPSolution::TSPSolution(std::size_t size) : 
    std::vector<unsigned>(size)
{
    Random rng;
    std::iota(this->begin(), this->end(), 0);
    std::shuffle(this->begin(), this->end(), rng.get_generator());
}

TSPSolution TSPSolution::swap(std::size_t i, std::size_t j)
{
    TSPSolution tmp = *this;
    std::swap(tmp.at(i), tmp.at(j));
    return tmp;
}

TSP::TSP(std::size_t ncities, std::vector<std::vector<double>> distances) :
    ncities(ncities),
    distances(distances)
{}

double TSP::fitness(TSPSolution solution)
const {
    double cost = 0;
    for(std::size_t i = 0; i < this->size(); ++i) {
        cost += this->distances[solution[i]][solution[(i+1)%this->size()]];
    }
    return cost;
}

double TSP::null_fitness()
const {
    return std::numeric_limits<double>().max();
}

bool TSP::best(double a, 
               double b)
const {
    return a < b;
}

std::vector<TSPSolution> TSP::neighborhood(TSPSolution solution)
const {
    std::vector<TSPSolution> neighbors;

    for(std::size_t i = 0; i < this->ncities; ++i) {
        for(std::size_t j = i+1; j < this->ncities; ++j) {
            neighbors.push_back(solution.swap(i,j));
        }
    }

    return neighbors;
}

std::size_t TSP::size()
const {
    return this->ncities;
}

TSP TSP::read()
{
    std::size_t ncities;
    std::vector<std::vector<double>> distances;
    std::vector<std::pair<double,double>> coordinates;

    std::cin >> ncities;
    distances.assign(ncities, std::vector<double>(ncities,0));
    coordinates.resize(ncities);

    for(std::pair<double,double> &coordinate : coordinates) {
        std::cin >> coordinate.first >> coordinate.second;
    }

    for(std::size_t i = 0; i < ncities; ++i) {
        for(std::size_t j = i+1; j < ncities; ++j) {
            double distance = std::sqrt(
                std::pow(coordinates[i].first - coordinates[j].first, 2)
                + std::pow(coordinates[i].second - coordinates[j].second, 2));
            distances[i][j] = distances[j][i] = distance;
        }    
    }

    return TSP(ncities, distances);
}