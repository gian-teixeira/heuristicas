#include <vector>
#include <iostream>
#include <string>
#include <cstring>
#include <functional>
#include <map>

#include <random.hpp>
#include <tsp.hpp>
#include <methods/ls.hpp>
#include <methods/ils.hpp>

template<typename SolutionType, typename FitnessType>
class Solver
{
private:
    LSManager<SolutionType,FitnessType> *ls;
    ILSManager<SolutionType,FitnessType> *ils;

public:
    Solver(Provider<SolutionType,FitnessType> *provider)
    {
        ls = new LSManager<SolutionType,FitnessType>(provider);
        ils = new ILSManager<SolutionType,FitnessType>(provider);
    }

    SolutionType solve(
        SolutionType initial,
        std::string method,
        std::vector<std::string> args)
    {
        if(method == "LS") return ls->search(initial, std::stoul(args[0]));
        else if(method == "ILS") return ils->search(initial, std::stoul(args[0]), std::stoul(args[1]));
    }

    ~Solver()
    {
        delete this->ls;
        delete this->ils;
    }
};

int main(int argc, char *argv[])
{
    std::string method;
    std::vector<std::string> args;

    method = std::string(argv[1],argv[1]+strlen(argv[1]));
    for(int i = 2; i < argc; ++i) {
        std::string tmp(argv[i],argv[i]+strlen(argv[i]));
        args.push_back(tmp);
    }

    TSP instance = TSP::read();
    Solver<TSP::solution_type,TSP::fitness_type> solver(&instance);

    TSPSolution answer = solver.solve(
        TSPSolution(instance.size()),
        method,
        args);

    std::cout << instance.fitness(answer) << std::endl;
    
    return 0;
}